// Pollux template scripts
document.addEventListener('DOMContentLoaded', function(){

  // window width
  var wWidth = window.innerWidth;
  window.addEventListener('resize', function() {
    wWidth = window.innerWidth;
  });

  // navbar toggler
  var headerNavbar = document.getElementById('headerNavbar'),
      headerNavbarTogglerHamburger = document.getElementById('navbar-toggler-hamburger');

  headerNavbar.addEventListener('show.bs.offcanvas', function () {
    headerNavbarTogglerHamburger.classList.add('open')
  })

  headerNavbar.addEventListener('hide.bs.offcanvas', function () {
    headerNavbarTogglerHamburger.classList.remove('open')
  })

  // scroll to payment items

  var paymentHrefs = document.getElementsByClassName('payment-href');
  for (let i = 0; i < paymentHrefs.length; i++){
    paymentHrefs[i].onclick = function(e) {
      e.preventDefault();
      var offset = 120;
      const element = document.querySelector(this.hash);
      const topPos = element.getBoundingClientRect().top + window.pageYOffset - offset
      window.scrollTo({
        top: topPos,
        behavior: 'smooth'
      })
    };
  }

  // popover btn help on header
  var popover = new bootstrap.Popover(document.getElementById('header-btn-help'), {
    trigger: 'focus'
  })
  
});